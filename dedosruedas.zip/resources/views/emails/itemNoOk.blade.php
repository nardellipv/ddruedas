<p style="text-align: center;"><img src="https://dedosruedas.com.ar/styleWeb/assets/images/logo.png"/></p>
<table style="height: 28px; background-color: #f2f2f2; width: 538.5px; margin-left: auto; margin-right: auto;">
    <tbody>
    <tr>
        <td style="width: 528.5px; text-align: left;">
            <p>&nbsp;</p>
            <p style="padding-left: 30px;">Publicación Rechazada</p>
            <p style="padding-left: 30px;"><strong>La
                    publicación {{ $item->brand->name }} {{ $item->pattern->name }} {{ $item->displacement }} fue
                    rechazada</strong></p>
            <p style="padding-left: 30px;">Motivo del rechazo:</p>
            <p style="padding-left: 30px;"><i>{{ $request->nook }}</i></p>
            <p style="text-align: center;"><span style="color: #993300;">Por favor edite la publicación modificando los puntos por el cual fue rechazado.</span>
            </p>
            <p>&nbsp;</p>
            <p style="text-align: center;"><span style="color: #993300;">Gracias por utilizar dedosruedas.com.ar</span>
            </p>
            <hr/>
            <p style="padding-left: 30px;"><sub>Por favor no responda este mail, para sugerencias o dudas, escribir a <a
                            href="mailto:info@dedosruedas.com.ar">info@dedosruedas.com.ar</a></sub></p>
        </td>
    </tr>
    </tbody>
</table>