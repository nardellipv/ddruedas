@extends('layouts.adminMain')

@section('content')
    @include('admin.parts._widget')
    @include('admin.parts._listItems')
    @include('admin.parts._listUsers')
@endsection

