<div class="page-section" style="margin-top:30px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="section-title" style="text-align:center; color:#333333; margin-bottom:45px;">
                    <h3 style="margin-bottom:5px;">WHY CHOOSE US</h3>
                    <p>It will help us find the Toyota you're looking for in your area.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="cs-services">
                    <div class="cs-media"> <i class="icon-fuel1 cs-color" style="font-size:70px;"> </i> </div>
                    <div class="cs-text">
                        <h6>OIL CHANGES </h6>
                        <p>Vivamus erat diam, condimentum in aliquet sed, bibendum at quam. Phasellus lacus mauris.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="cs-services">
                    <div class="cs-media"> <i class="icon-car230 cs-color" style="font-size:40px"> </i> </div>
                    <div class="cs-text">
                        <h6>AIR CONDITIONING</h6>
                        <p>Nulla a gravida purus. Fusce at interdum libero, at. Vivamus erat diam, condimentum in bibendum                                            at quam.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="cs-services">
                    <div class="cs-media"> <i class="icon-energy42 cs-color" style="font-size:40px"> </i> </div>
                    <div class="cs-text">
                        <h6>AUTO ELECTRIC </h6>
                        <p>Etiam et maximus nisi, nec scelerisque neque. Nunc euismod iaculis urna, id eleifend lorem                                             aliquet at. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="cs-services">
                    <div class="cs-media"> <i class="icon-car36 cs-color" style="font-size:40px"> </i> </div>
                    <div class="cs-text">
                        <h6>BRAKE SERVICE </h6>
                        <p>Vivamus erat diam, condimentum in aliquet sed, bibendum at quam. Phasellus lacus mauris.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="cs-services">
                    <div class="cs-media"> <i class="icon-car228 cs-color" style="font-size:40px"> </i> </div>
                    <div class="cs-text">
                        <h6>TRANSMISSION</h6>
                        <p>Nulla a gravida purus. Fusce at interdum libero, at. Vivamus erat diam, condimentum in bibendum                                            at quam.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <div class="cs-services">
                    <div class="cs-media"> <i class="icon-transport177 cs-color" style="font-size:40px"> </i> </div>
                    <div class="cs-text">
                        <h6>TIRE &amp; WHEEL SERVICE</h6>
                        <p>Etiam et maximus nisi, nec scelerisque neque. Nunc euismod iaculis urna, id eleifend lorem                                              aliquet at. </p>
                    </div>
                </div>
            </div>
            <div class="cs-seprater" style="text-align:center;"> <span> <i class="icon-transport177"> </i> </span> </div>
        </div>
    </div>
</div>