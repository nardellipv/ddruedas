@extends('layouts.main')

@section('body', 'wp-automobile')

<style>
    #mapCanvas {
        width: 100%;
        height: 50%;
    }
</style>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC9hFnaDIySB3aNRjDNehx7qo_UdF4JgvU"></script>

<script>
    function initMap() {
        var map;
        var bounds = new google.maps.LatLngBounds();
        var mapOptions = {
            mapTypeId: 'roadmap'
        };

        // Display a map on the web page
        map = new google.maps.Map(document.getElementById("mapCanvas"), mapOptions);
        map.setTilt(50);

        // Multiple markers location, latitude, and longitude
        var markers = [
                @foreach($dealers as $dealer)
            ['{{ $dealer->user->province->name }}, Argentina', {{ $dealer->lat }}, {{ $dealer->lng }}],
            @endforeach
        ];

        // Info window content
        var infoWindowContent = [
                @foreach($dealers as $dealer)
            ['<div class="info_content">' +
            '<h3>{{ $dealer->nameAgency }}</h3>' +
            '<p><b>Teléfono:</b> {{ $dealer->phoneWsp }}</p>' + '</div>'],
            @endforeach
        ];

        // Add multiple markers to map
        var infoWindow = new google.maps.InfoWindow(), marker, i;

        // Place each marker on the map
        for (i = 0; i < markers.length; i++) {
            var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
            bounds.extend(position);
            marker = new google.maps.Marker({
                position: position,
                map: map,
                title: markers[i][0]
            });

            // Add info window to marker
            google.maps.event.addListener(marker, 'click', (function (marker, i) {
                return function () {
                    infoWindow.setContent(infoWindowContent[i][0]);
                    infoWindow.open(map, marker);
                }
            })(marker, i));

            // Center the map to fit all markers on the screen
            map.fitBounds(bounds);
        }

        // Set zoom level
        var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function (event) {
            this.setZoom(5);
            google.maps.event.removeListener(boundsListener);
        });

    }

    // Load initialize function
    google.maps.event.addDomListener(window, 'load', initMap);
</script>

@section('content')
    <div class="main-section">
        <div class="page-section">
            <div class="container">
                <div class="row">
                    <div class="section-fullwidth col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="cs-agent-filters">
                                    <span class="cs-filters-title">Buscar Agencia</span>
                                    <div class="row">
                                        <form action="{{ route('dealer.search') }}" method="GET">
                                            <div class="cs-agent-filtration">
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <small style="color: darkgrey">Buscar por Provincia o Nombre</small>
                                                    <div class="cs-select-dropdown">
                                                        <label>Provincia</label>
                                                        <select tabindex="1" class="chosen-select" name="province"
                                                                autocomplete="off">
                                                            <option value="">Provincia</option>
                                                            @foreach($provinces as $province)
                                                                <option value="{{ $province->id }}">{{ $province->name }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="cs-select-location">
                                                        <label>Nombre Agencia</label>
                                                        <input type="text" name="nameAgency"
                                                               placeholder="Nombre Agencia" autocomplete="off"/>
                                                        <a href="#"><i class="icon-car228"></i></a>
                                                        <small>&nbsp;</small>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="cs-search-btn">
                                                        <input type="submit" value="Buscar Agencia"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div id="mapCanvas"></div>
                                    </div>


                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="cs-ag-search">
                                            <ul class="filter-list">
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'A']) }}">A</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'B']) }}">B</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'C']) }}">C</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'D']) }}">D</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'E']) }}">E</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'F']) }}">F</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'G']) }}">G</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'H']) }}">H</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'I']) }}">I</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'J']) }}">J</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'K']) }}">K</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'L']) }}">L</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'M']) }}">M</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'N']) }}">N</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'O']) }}">O</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'P']) }}">P</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'Q']) }}">Q</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'R']) }}">R</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'S']) }}">S</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'T']) }}">T</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'U']) }}">U</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'V']) }}">V</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'W']) }}">W</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'X']) }}">X</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'Y']) }}">Y</a>
                                                </li>
                                                <li><a href="{{ route('dealer.filterWord', ['letra'=>'Z']) }}">Z</a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="row">
                                            @forelse($dealers as $dealer)
                                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                    <div class="cs-agent-listing">
                                                        <div class="cs-media">
                                                            <figure>
                                                                <a href="#"><img src="{{ $dealer->logo }}"
                                                                                 class="img-responsive"
                                                                                 alt="{{ $dealer->nameAgency }}"/></a>
                                                            </figure>
                                                        </div>
                                                        <div class="cs-text">
                                                            <div class="cs-post-title">
                                                                <h6><a href="{{ route('dealer.detail', [$dealer->nameAgency,$dealer]) }}">{{ $dealer->nameAgency }}</a></h6>
                                                            </div>
                                                            <address>{{ $dealer->user->province->name }}
                                                                , {{ $dealer->user->region->name }}</address>
                                                            <a href="{{ route('dealer.detail', [$dealer->nameAgency,$dealer]) }}"
                                                               class="contact-btn"><i class="icon-eye">
                                                                </i>Ver detalles</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            @empty
                                                <h5 style="text-align: center">No encotramos ninguna agencia</h5>
                                            @endforelse
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <nav>
                                            <ul class="pagination">
                                                {{ $dealers->render() }}
                                            </ul>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
