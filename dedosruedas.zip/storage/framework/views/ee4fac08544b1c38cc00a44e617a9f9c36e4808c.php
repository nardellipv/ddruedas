<?php $__env->startSection('body', 'wp-automobile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-section">
        <div class="page-section"
             style="background:url(<?php echo e(asset('styleWeb/assets/images/user-bg-img.jpg')); ?>) no-repeat;background-size:cover;min-height:175px;margin-top:-30px;margin-bottom:-129px;"></div>
        <div class="page-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="cs-user-account-holder">
                            <div class="row">
                                <?php echo $__env->make('web.user._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="cs-user-section-title"><h4>Publicaciones Activas</h4>
                                        <a href="<?php echo e(route('dashboard.publicMoto')); ?>"
                                           class="btn btn-danger btn-sm"><i class="icon-plus"></i> Publicar
                                            Moto</a>
                                        <ul>
                                            <li><a href="#" class="cs-active-btn">Activos</a>
                                                <ul>
                                                    <li>
                                                        <a href="<?php echo e(route('dashboard.listVehiclesExipire')); ?>">Vencidos</a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('dashboard.listVehiclesPaused')); ?>">Pausados</a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('dashboard.listVehiclesRejected')); ?>">Rechazados</a>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>

                                    </div>
                                </div>
                                <ul class="cs-featurelisted-car">
                                    <?php $__empty_1 = true; $__currentLoopData = $listMotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listMoto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="cs-media">
                                                <figure>
                                                    <a href="#">
                                                        <?php if(count($listMoto->pictures)>= 1): ?>
                                                            <img src="<?php echo e(asset('users/'.Auth::user()->id.'/images/items/700x700-'.$listMoto->pictures[0]->name)); ?>"
                                                                 class="img-responsive"/>
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('styleWeb/assets/images/sinimagen.jpg')); ?>"
                                                                 class="img-responsive">
                                                        <?php endif; ?>
                                                    </a>
                                                </figure>
                                            </div>
                                            <div class="cs-text">
                                                <?php if($listMoto->status == 'Pendiente'): ?>
                                                    <span class="cs-featured">Pendiente Aprobación</span>
                                                <?php endif; ?>
                                                <h6>
                                                    <a href="<?php echo e(route('item.detail', $listMoto)); ?>"><?php echo e($listMoto->brand->name); ?>

                                                        <em><?php echo e($listMoto->pattern->name); ?></em>
                                                    </a><?php echo e($listMoto->money); ?><?php echo e($listMoto->price); ?></h6>
                                                <p>
                                                    <a href="<?php echo e(route('item.detail', $listMoto)); ?>"><?php echo e($listMoto->type->name); ?> </a>
                                                </p>
                                                <div class="post-options">
                                                    <span>Publicado: <em><?php echo e(\Carbon\Carbon::parse($listMoto->updated_at)->format('d M Y')); ?></em></span>
                                                    <span>Vencimiento: <em><?php echo e(\Carbon\Carbon::parse($listMoto->expire)->format('d M Y')); ?></em></span>
                                                    <p>
                                                        <span><a href="#">Total Visitas: <em><?php echo e($listMoto->visit); ?></em></a></span>
                                                </div>
                                                <div class="cs-post-types">
                                                    <div class="cs-post-list">
                                                        <div class="cs-edit-post">
                                                            <a href="#" data-toggle="tooltip" data-placement="top"
                                                               title="Editar Item"><i class="icon-edit2"></i></a>
                                                            <a href="#" data-toggle="tooltip" data-placement="top"
                                                               title="Borrar"><i class="icon-trash-o"></i></a>
                                                        </div>
                                                        <div class="cs-list">
                                                            <a href="https://facebook.com/sharer/sharer.php?u=<?php echo e(route('item.detail', $listMoto)); ?>"
                                                               data-toggle="tooltip" data-placement="top"
                                                               target="_blank"
                                                               title="Compartir"><i class="icon-forward4"></i></a>
                                                            <a href="<?php echo e(route('actionItems.download', $listMoto)); ?>"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="Descargar"><i class="icon-box-add"></i></a>
                                                            <a href="<?php echo e(route('actionItems.paused', $listMoto)); ?>"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="Pausar"><i class="icon-pause"></i></a>
                                                            <a href="<?php echo e(route('actionItems.show', $listMoto)); ?>"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="Editar Item"><i class=" icon-edit2"></i></a>
                                                            <a href="<?php echo e(route('actionItems.delete', $listMoto)); ?>"
                                                               data-toggle="tooltip" data-placement="top"
                                                               title="Borrar"><i class="icon-trash-o"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <h4 style="text-align: center">No tienes Motos publicadas</h4>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\dedosruedas\resources\views/web/user/listActive.blade.php ENDPATH**/ ?>