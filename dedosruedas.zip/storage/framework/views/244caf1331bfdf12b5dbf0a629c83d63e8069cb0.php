<div class="page-section" style="background: rgba(237, 240, 245, 1); padding-top:70px; padding-bottom:70px;">
    <div class="container">
        <div class="row">
            <div class="section-fullwidtht col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                    <div class="cs-auto-listing cs-auto-box">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="cs-element-title">
                                <h2>Últimas publicaciones</h2>
                            </div>
                        </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <ul class="cs-auto-box-slider row">
                                <?php $__currentLoopData = $lastItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lastItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                                        <a href="<?php echo e(route('item.detail', $lastItem)); ?>">
                                        <div class="cs-media">
                                            <?php if(count($lastItem->pictures)>= 1): ?>
                                            <figure>
                                                <img src="<?php echo e(asset('users/'.$lastItem->user_id.'/images/items/700x700-'.$lastItem->pictures[0]->name)); ?>"
                                                     alt="<?php echo e($lastItem->brand->name); ?>"/>
                                            </figure>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('styleWeb/assets/images/sinimagen.jpg')); ?>"
                                                     class="img-responsive">
                                            <?php endif; ?>
                                            <div class="caption-text">
                                                <h2> <?php echo e($lastItem->brand->name); ?>

                                                    <?php echo e($lastItem->pattern->name); ?>

                                                    <?php echo e($lastItem->displacement); ?>

                                                </h2>
                                            </div>
                                        </div>
                                        </a>
                                        <div class="auto-text cs-bgcolor">
                                            <span><?php echo e($lastItem->money); ?> <?php echo e($lastItem->price); ?></span>
                                            <small>Año <?php echo e(\Carbon\Carbon::parse($lastItem->year)->format('Y')); ?></small>
                                            <a href="<?php echo e(route('item.detail', $lastItem)); ?>"
                                               class="cs-button pull-right"><i class="icon-arrow_forward"></i></a>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Webs\dedosruedas\resources\views/web/parts/_browseMoto.blade.php ENDPATH**/ ?>