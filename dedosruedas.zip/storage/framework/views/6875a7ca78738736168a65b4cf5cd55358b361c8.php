<?php $__env->startSection('body', 'wp-automobile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-section">
        
        <div class="page-section" style="padding-top:40px; padding-bottom:60px;">
            <div class="container">
                <div class="row">
                    <div class="section-fullwidtht col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <!--Element Section Start-->
                            <div class="cs-contact-form">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="cs-section-title">
                                        <h3 style="text-transform:uppercase !important;">Formulario de contacto</h3>
                                        <p style="text-transform:uppercase;font-size:11px;color:#999999 !important;">
                                            Cualquier duda o sugerencia sobre el sitio le pedimos que se ponga en
                                            contacto con nuestros
                                            representantes <br> a través del siguiente formulario.</p>
                                    </div>
                                    <?php echo $__env->make('alerts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                                <form method="POST" action="<?php echo e(route('home.sendContact')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="cs-form-holder">
                                                    <div class="input-holder"><input type="text" name="name"
                                                                                     placeholder="Nombre"
                                                        value="<?php echo e(old('name')); ?>"><i
                                                                class=" icon-user"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="cs-form-holder">
                                                    <div class="input-holder"><input type="email" name="email"
                                                                                     placeholder="Email Address"
                                                                                     value="<?php echo e(old('email')); ?>"><i
                                                                class=" icon-envelope"></i></div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="cs-form-holder">
                                                    <div class="input-holder" id="data-toggle">
                                                        <input type="checkbox" id="cbox2" name="newsletter" value="1" checked>
                                                        <label for="cbox2">Deseo suscribirme al newsletter</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="cs-form-holder">
                                                    <div class="input-holder">
                                                        <textarea name="comment"
                                                                  placeholder="Comentarios a nuestros representantes"><?php echo e(old('comment')); ?></textarea><i></i>
                                                        <?php echo htmlFormSnippet(); ?>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                <div class="cs-btn-submit cs-color">
                                                    <input type="submit" value="Enviar">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\dedosruedas\resources\views/web/help/contact.blade.php ENDPATH**/ ?>