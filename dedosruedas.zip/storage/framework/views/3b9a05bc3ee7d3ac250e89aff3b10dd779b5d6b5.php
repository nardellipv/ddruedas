<?php $__env->startSection('body', 'wp-automobile single-post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-section">
        <div class="page-section" style=" padding-top: 75px; padding-bottom:50px;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="cs-page-not-found">
                            <div class="cs-text">
                                <p>Lo siento, esta página no existe.</p>
                                <span class="cs-error">404<em> Error</em></span>
                            </div>

                        </div>
                    </div>
                    <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                        <div class="cs-seprater-v1">
                            <a href="<?php echo e(route('home')); ?>">
                            <span><i class="icon-home2 cs-bgcolor"> </i></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\dedosruedas\resources\views/errors/404.blade.php ENDPATH**/ ?>