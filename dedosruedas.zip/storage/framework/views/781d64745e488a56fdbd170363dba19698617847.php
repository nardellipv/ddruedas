<div class="page-section" style=" padding-top:70px; padding-bottom:50px;">
    <div class="container">
        <div class="row">
            <div class="section-fullwidtht col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="row">
                    <!--Element Section Start-->
                    <div class="cs-blog cs-blog-grid">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="cs-section-title">
                                <h3 style="text-transform:uppercase !important;">Últimas Noticias</h3>
                                <p>Todas las noticias relacionadas con el mundo de las 2 ruedas.</p>
                            </div>
                        </div>
                        <?php $__currentLoopData = $lastPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                                <div class="cs-blog-listing blog-grid">
                                    <div class="cs-media">
                                        <figure>
                                            <a href="#"><img src="<?php echo e(asset('styleWeb/assets/images/blog/'.$lastPost->photo)); ?>"
                                                                 alt="<?php echo e($lastPost->title); ?>"/></a>
                                        </figure>
                                    </div>
                                    <div class="blog-text">
                                        <div class="post-title">
                                            <h4><a href="<?php echo e(route('blog.post', $lastPost->slug)); ?>"><?php echo e($lastPost->title); ?></a></h4>
                                        </div>
                                        
                                        <div class="post-meta">
                                            <i class="icon-calendar"></i>
                                            <em> <?php echo e(\Carbon\Carbon::parse($lastPost->created)->format('d-m-Y')); ?></em>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Webs\dedosruedas\resources\views/web/parts/_lastBlog.blade.php ENDPATH**/ ?>