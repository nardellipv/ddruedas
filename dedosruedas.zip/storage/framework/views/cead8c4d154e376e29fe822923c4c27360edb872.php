<?php if(count($errors) > 0): ?>
    <div class="alert alert-warning alert-dismissable"  style="text-align: center;">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
        <i class="icon-warning3" style="font-size: 20px"></i>
        <span style="font-size: 20px"> Por favor verifique los siguientes errores </span>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li style="list-style: none;"> <?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH D:\Webs\dedosruedas\resources\views/alerts/error.blade.php ENDPATH**/ ?>