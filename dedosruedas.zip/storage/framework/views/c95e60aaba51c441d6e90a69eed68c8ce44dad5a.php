<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('styleWeb/assets/css/woocommerce.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/chosen.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body', 'woocommerce woocommerce-page single-product wp-automobile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-section">
        <div class="page-section">
            <div class="container">
                <div class="row">
                    <div class="section-fullwidth col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="page-content col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                <div class="row">
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="site-main">
                                            <div class="columns-3">
                                                <ul class="products">
                                                    <?php $__empty_1 = true; $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <li class="product">
                                                            <a href="<?php echo e(route('accessory.detail', $accessory)); ?>">
                                                                <img src="<?php echo e(asset('users/'.$accessory->user_id.'/images/accessory/700x700-'.$accessory->picture)); ?>"
                                                                     alt="<?php echo e($accessory->name); ?>"/>
                                                                <h5><?php echo e($accessory->name); ?></h5>
                                                                <span class="price">
                                                                <span class="amount">$ <?php echo e($accessory->price); ?></span>
                                                                </span>
                                                            </a>
                                                        </li>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <h4 style="text-align: center">No hay accesorios todavía</h4>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                            <nav>
                                                <ul class="pagination">
                                                    <?php echo e($accessories->render()); ?>

                                                </ul>
                                            </nav>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php echo $__env->make('web.accessories._asideAccessories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\dedosruedas\resources\views/web/accessories/list.blade.php ENDPATH**/ ?>