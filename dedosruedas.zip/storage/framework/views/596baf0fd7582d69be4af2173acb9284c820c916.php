<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('styleWeb/assets/css/bootstrap-slider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/jquery.mCustomScrollbar.css')); ?>" rel="stylesheet">

    <style>
        .boton-oculto {
            display: none;
        }

        #fixedbutton {
            position: fixed;
            bottom: 40px;
            right: 40px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body', 'wp-automobile single-page'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-section">

        <div class="page-section">
            <div class="container">
                <div class="row">
                    <?php echo $__env->make('web.items._asideList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="section-content col-lg-9 col-md-9 col-sm-12 col-xs-12">
                        <form action="<?php echo e(route('item.compare')); ?>" method="GET">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="auto-sort-filter">
                                        <div class="auto-show-resuilt">
                                            <div class="auto-your-search">
                                                <ul class="filtration-tags">
                                                    <?php if(isset($provinceName->name)): ?>
                                                        <li><a href="#"><?php echo e($provinceName->name); ?> <i
                                                                        class="icon-star-full"
                                                                        style="color: black"></i></a>
                                                        </li>
                                                    <?php endif; ?>
                                                    <?php if(isset($typeName->name)): ?>
                                                        <li><a href="#"><?php echo e($typeName->name); ?><i class="icon-star-full"
                                                                                                style="color: black"></i></a>
                                                        </li>
                                                    <?php endif; ?>
                                                    <?php if(isset($priceFrom)): ?>
                                                        <li><a href="#">$<?php echo e($priceFrom); ?></a></li>
                                                        <li><a href="#">A</a></li>
                                                        <li><a href="#">$<?php echo e($priceTo); ?><i class="icon-star-full"
                                                                                          style="color: black"></i></a>
                                                        </li>
                                                        <li><a href="#"><?php echo e($yearFrom); ?></a></li>
                                                        <li><a href="#">A</a></li>
                                                        <li><a href="#"><?php echo e($yearTo); ?><i class="icon-star-full"
                                                                                        style="color: black"
                                                                                        style="color: black"></i></a>
                                                        </li>
                                                        <a href="<?php echo e(route('item.index')); ?>" class="clear-tags cs-color">Borrar
                                                            Filtro</a>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php if(!isset($priceFrom)): ?>
                                            <div class="auto-list">
                                                <span>Ordenar</span>
                                                <ul>
                                                    <li>
                                                        <div class="cs-select-post">
                                                            <select data-placeholder="Ordenar"
                                                                    class="chosen-select-no-single"
                                                                    tabindex="5"
                                                                    onchange="window.location.href=this.options[this.selectedIndex].value;">
                                                                <option>Filtro</option>
                                                                <option value="<?php echo e(route('item.index')); ?>">Listado
                                                                    Completo
                                                                </option>
                                                                <option value="<?php echo e(route('item.filter', ['filtro'=>'menor-precio'])); ?>">
                                                                    Menor Precio
                                                                </option>
                                                                <option value="<?php echo e(route('item.filter', ['filtro'=>'mayor-precio'])); ?>">
                                                                    Mayor Precio
                                                                </option>
                                                                <option value="<?php echo e(route('item.filter', ['filtro'=>'ultimo-publicado'])); ?>">
                                                                    Últimas
                                                                    Publicadas
                                                                </option>
                                                            </select>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php $__empty_1 = true; $__currentLoopData = $listItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="auto-listing">
                                            <div class="cs-media">
                                                <figure>
                                                    <?php if(count($listItem->pictures)>= 1): ?>
                                                        <img src="<?php echo e(asset('users/'.$listItem->user_id.'/images/items/700x700-'.$listItem->pictures[0]->name)); ?>"
                                                             alt="<?php echo e($listItem->brand->name); ?>"/>
                                                    <?php else: ?>
                                                        <img src="<?php echo e(asset('styleWeb/assets/images/sinimagen.jpg')); ?>"
                                                             class="img-responsive">
                                                    <?php endif; ?>
                                                </figure>
                                            </div>
                                            <div class="auto-text">
                                                <div class="post-title">
                                                    <h4>
                                                        <a href="<?php echo e(route('item.detail', $listItem->id)); ?>"><?php echo e($listItem->brand->name); ?>

                                                            <small><?php echo e($listItem->pattern->name); ?></small>
                                                        </a></h4>
                                                    <div class="auto-price"><span
                                                                class="cs-color"><?php echo e($listItem->money); ?> <?php echo e($listItem->price); ?></span>
                                                    </div>
                                                    <?php if($listItem->user->dealer): ?>
                                                        <a href="<?php echo e(route('dealer.detail', [$listItem->user->dealer->nameAgency, $listItem->user->dealer->id])); ?>"><img
                                                                    src="<?php echo e($listItem->user->dealer->logo); ?>"
                                                                    alt="<?php echo e($listItem->user->dealer->nameAgency); ?>"
                                                                    class="img-responsive" style="width: 20%"/></a>
                                                    <?php endif; ?>
                                                </div>
                                                <ul class="auto-info-detail">
                                                    <li>Año<span><?php echo e($listItem->year); ?></span></li>
                                                    <li>Km<span><?php echo e($listItem->mileage); ?></span></li>
                                                    <li>Condición<span><?php echo e($listItem->condition); ?></span></li>
                                                </ul>
                                                <p><span><?php echo e($listItem->user->province->name); ?>

                                                        , <?php echo e($listItem->user->region->name); ?></span></p>
                                                <p><span><?php echo e($listItem->type->name); ?></span></p>


                                                <div class="cs-checkbox">
                                                    <input type="checkbox" name="compare[]" value="<?php echo e($listItem->id); ?>"
                                                           id="<?php echo e($listItem->id); ?>" class="compare">
                                                    <label for="<?php echo e($listItem->id); ?>">Compare</label>
                                                </div>

                                            </div>

                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <h4 style="text-align: center">Lo sentimos, no se encontraron resultados</h4>
                                <?php endif; ?>
                            </div>

                            <div class="cs-field boton-oculto" id="fixedbutton">
                                <div class="cs-btn-submit">
                                    <input type="submit" value="Comparar Seleccionados"
                                           style="background-color: darkslateblue">
                                </div>
                            </div>
                        </form>


                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <nav>
                                <ul class="pagination">
                                    <?php echo e($listItems->render()); ?>

                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('styleWeb/assets/scripts/bootstrap-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('styleWeb/assets/scripts/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

    <script>
        $('input[class=compare]').change(function () {
            if ($('input[class="compare"]').is(':checked')) {
                $(".boton-oculto").show()
            } else {
                $(".boton-oculto").hide()
            }
            if ($('input[class="compare"]:checked').length > 3) {
                alert('Solo puedes comparar 3 motos como máximo')
                $(".boton-oculto").hide()
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\dedosruedas\resources\views/web/items/list.blade.php ENDPATH**/ ?>