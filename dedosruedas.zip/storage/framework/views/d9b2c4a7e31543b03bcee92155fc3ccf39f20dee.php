<?php $__env->startSection('body', 'cs-agent-detail wp-automobile'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-section">
        <div class="page-section" style="background-color:#fafafa; padding:40px 0;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="cs-admin-info">
                            <div class="cs-media" style="width: 16%">
                                <figure>
                                    <img src="<?php echo e($dealer->logo); ?>" alt="<?php echo e($dealer->nameAgency); ?>"
                                         class="img-responsive"/>
                                </figure>
                            </div>
                            <div class="cs-text">
                                <div class="cs-title">
                                    <h3><?php echo e($dealer->nameAgency); ?></h3>
                                </div>
                                <address><?php echo e($dealer->user->province->name); ?><br/>
                                    <?php echo e($dealer->user->region->name); ?></address>
                                <ul>
                                    <li>
                                        <span>Teléfono Principal<i class="icon-keyboard_arrow_down"></i></span>
                                        <?php echo e($dealer->phone); ?>

                                        <ul>
                                            <?php if($dealer->phone1): ?>
                                                <li>
                                                    <span>Teléfono</span>
                                                    <?php echo e($dealer->phone1); ?>

                                                </li>
                                            <?php endif; ?>
                                            <?php if($dealer->phoneWsp): ?>
                                                <li>
                                                    <span>WhatsApp</span>
                                                    <?php echo e($dealer->phoneWsp); ?>

                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>Sitio Web</span>
                                        <a href="<?php echo e($dealer->web); ?>"
                                           rel="ugc,nofollow"><?php echo e(Str::limit($dealer->web,30)); ?></a>
                                    </li>
                                    <li>
                                        <span>Email</span>
                                        <a href="#"><?php echo e($dealer->email); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-section" style="border-top:1px solid #eee; border-bottom:1px solid #eee; padding:20px 0;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-9 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <div class="cs-social-media pull-right">
                                    <ul>
                                        <li><a href="<?php echo e($dealer->facebook); ?>" target="_blank"><i
                                                        class="icon-facebook22"></i></a></li>
                                        <li><a href="<?php echo e($dealer->instagram); ?>" target="_blank"><i
                                                        class="icon-instagram"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-section">
            <div class="container">
                <div class="row">
                    <div class="section-fullwidth col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="row">
                            <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                <div class="rich_editor_text">
                                    <strong>Sobre <?php echo e($dealer->nameAgency); ?></strong>
                                    <p><?php echo e($dealer->about); ?>.</p>
                                </div>

                                <div class="rich_editor_text">
                                    <strong>Listado de motos</strong>
                                </div>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="auto-listing">
                                        <div class="cs-media">
                                            <figure><img alt="<?php echo e($item->brand->name); ?>" src="<?php echo e($item->name); ?>"
                                                         class="img-responsive"
                                                         style="width: 73%; margin-left: 15%"></figure>
                                        </div>
                                        <div class="auto-text">
                                            <div class="post-title">
                                                <h4><a href="<?php echo e(route('item.detail', $item)); ?>"><?php echo e($item->brand->name); ?>

                                                        <small><?php echo e($item->pattern->name); ?></small>
                                                    </a></h4>
                                                <div class="auto-price"><span
                                                            class="cs-color"><?php echo e($item->money); ?> <?php echo e($item->price); ?></span>
                                                </div>
                                            </div>
                                            <ul class="auto-info-detail">
                                                <li>Año<span><?php echo e($item->year); ?></span></li>
                                                <li>Kilometraje<span><?php echo e($item->mileage); ?></span></li>
                                                <li>Cilindrada<span><?php echo e($item->displacement); ?></span></li>
                                                <li>Tipo<span><?php echo e($item->type->name); ?></span></li>
                                            </ul>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <nav>
                                        <ul class="pagination">
                                            <?php echo e($items->render()); ?>

                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                <div class="cs-tabs-holder">
                                    <div class="cs-location-tabs">
                                        <!--Tabs Start-->
                                        <div class="cs-tabs horizontal vertical">

                                            <ul class="nav nav-tabs">
                                                <li class="active"><a data-toggle="tab" href="#home"><i
                                                                class="icon-location-pin"></i>Ubicación</a></li>
                                            </ul>

                                            <div class="tab-content">
                                                <div id="home" class="tab-pane fade in active">
                                                    <iframe
                                                            width="100%"

                                                            height="340px"
                                                            frameborder="0" style="border:0"
                                                            src="https://www.google.com/maps/embed/v1/place?key=AIzaSyD7eUalpQrZ5TA9BrE5XgsudugZC7TIPYo
                                        &q=<?php echo e($dealer->address .','. $dealer->user->region->name . $dealer->user->province->name); ?>"
                                                            allowfullscreen>
                                                    </iframe>
                                                </div>
                                            </div>

                                        </div>

                                        <!--Tabs End-->
                                    </div>
                                    <div class="cs-agent-contact-form">
                                        <span class="cs-form-title">Contactar Agencia</span>
                                        <form>
                                            <input type="text" placeholder="Nombre"/>
                                            <input type="email" placeholder="Email"/>
                                            <textarea name="menssageDealer"></textarea>
                                            <input class="cs-bgcolor" type="submit" value="Contactar Agencia"/>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-section" style="background:#19171a;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="cs-ad" style="text-align:center; padding:55px 0 32px;">
                            <div class="cs-media">
                                <figure>
                                    <img src="assets/extra-images/cs-ad-img.jpg" alt=""/>
                                </figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\dedosruedas\resources\views/web/dealer/detail.blade.php ENDPATH**/ ?>