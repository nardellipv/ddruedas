<header id="header">
    <div class="container">
        <div class="row">
            <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">
                <div class="cs-logo">
                    <div class="cs-media">
                        <figure><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('styleWeb/assets/images/logo.png')); ?>"
                                                              alt=""/></a></figure>
                    </div>
                </div>
            </div>
            <div class="col-lg-10 col-md-10 col-sm-12 col-xs-12">
                <div class="cs-main-nav pull-right">
                    <nav class="main-navigation">
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('item.index')); ?>">Listado</a></li>
                            <li><a href="<?php echo e(route('accessory.index')); ?>">Accesorios</a></li>
                            <li><a href="<?php echo e(route('dealer.index')); ?>">Agencias</a></li>
                            <li><a href="<?php echo e(route('dealer.index')); ?>">Oficios</a></li>
                            
                            <li><a href="<?php echo e(route('contact')); ?>">Contacto</a></li>
                            

                            <?php if(auth()->guard()->check()): ?>
                                <li class="cs-user-option">
                                    <div class="cs-login">
                                        <div class="cs-login-dropdown"><a href="#"><i class="icon-user2"></i> <?php echo e(Auth::user()->name); ?> <i
                                                        class="icon-chevron-down2"></i></a>
                                            <div class="cs-user-dropdown">
                                                <ul>
                                                    <li><a href="<?php echo e(route('dashboard.listVehicles')); ?>">Mis Motos</a>
                                                    </li>
                                                    <li><a href="<?php echo e(route('dashboard.listAccesories')); ?>">Mis Accesorios</a>
                                                    </li>
                                                    <li><a href="<?php echo e(route('favorite.index')); ?>">Mis Favoritos</a>
                                                    </li>
                                                    <li><a href="<?php echo e(route('profile.viewProfile')); ?>">Mi Perfil</a>
                                                    </li>
                                                </ul>
                                                <a class="btn-sign-out" href="<?php echo e(route('logout')); ?>"
                                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                                            class="icon fa fa-sign-out">Salir</a></div>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                        <a href="<?php echo e(route('dashboard.publicMoto')); ?>"
                                           class="cs-bgcolor btn-form"
                                           aria-hidden="true"><i class="icon-plus"></i> Publicar Moto</a>
                                    </div>
                                </li>
                            <?php endif; ?>
                            <?php if(auth()->guard()->guest()): ?>
                                <li><a href="<?php echo e(route('login')); ?>">Ingresar</a></li>
                                <li><a href="<?php echo e(route('register')); ?>">Registrarse</a></li>
                            <?php endif; ?>
                        </ul>
                    </nav>


                    <div class="cs-user-option hidden-lg visible-sm visible-xs">
                        <div class="cs-login">
                            <div class="cs-login-dropdown"><a href="#"> Ayuda <i class="icon-chevron-down2"></i></a>
                                <div class="cs-user-dropdown">
                                    <ul>
                                        <li><a href="<?php echo e(route('about')); ?>">Sobre Nosotros</a></li>
                                        <li><a href="<?php echo e(route('term')); ?>">Términos y Condiciones</a></li>
                                        <li><a href="<?php echo e(route('faqs')); ?>">Preguntas Frecuentes</a></li>
                                    </ul>
                                    <a class="btn-sign-out" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a></div>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="cs-user-option hidden-lg visible-sm visible-xs">
                        <div class="cs-login">
                            <?php if(auth()->guard()->check()): ?>
                            <div class="cs-login-dropdown"><a href="#">
                                    <i class="icon-user2"></i> <?php echo e(Auth::user()->name); ?> <i
                                            class="icon-chevron-down2"></i></a>
                                <div class="cs-user-dropdown">
                                    <ul>
                                        <li><a href="<?php echo e(route('dashboard.listVehicles')); ?>">Mis Motos</a>
                                        </li>
                                        <li><a href="<?php echo e(route('dashboard.listAccesories')); ?>">Mis Accesorios</a>
                                        </li>
                                        <li><a href="<?php echo e(route('favorite.index')); ?>">Mis Favoritos</a>
                                        </li>
                                        <li><a href="<?php echo e(route('profile.viewProfile')); ?>">Mi Perfil</a>
                                        </li>
                                    </ul>
                                    <a class="btn-sign-out" href="#">Logout</a></div>
                                <a href="<?php echo e(route('dashboard.publicMoto')); ?>" class="cs-bgcolor btn-form"
                                   aria-hidden="true"><i class="icon-plus"></i> Publicar Moto</a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header><?php /**PATH D:\Webs\dedosruedas\resources\views/web/parts/_menu.blade.php ENDPATH**/ ?>