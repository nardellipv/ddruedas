<div class="page-section" style="background: url(<?php echo e(asset('styleWeb/assets/extra-images/full-section-img.jpg')); ?>)no-repeat; background-size:cover; padding:50px 0 10px; text-shadow: 3px 4px 6px rgba(0,0,0,.37);margin-top:-30px;">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="image-frame defualt" style="padding-top:40px;">
                    <div class="cs-media">
                        
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="cs-column-text">
                    <span class="cs-bgcolor" style="color:#fff; padding:5px 20px; text-shadow: 3px 4px 6px rgba(0,0,0,.37); margin-bottom:20px;">Cambia tu moto de forma fácil</span>
                    <h1 style="color:#fff !important; font-size:50px !important; line-height:53px !important; text-shadow: 3px 4px 6px rgba(0,0,0,.37);">Publica tu moto totalmente gratis!!!.</h1>
                    <a href="<?php echo e(route('dashboard.publicMoto')); ?>" class="cs-button" style="color:#fff;width:80px; height:80px; border-radius:50%; line-height:17px; text-align:center; padding-top:20px; letter-spacing:1px; font-weight:bold; vertical-align:middle; text-shadow: 3px 4px 6px rgba(0,0,0,.37); ">Publicar Moto</a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Webs\dedosruedas\resources\views/web/parts/_mainBanner.blade.php ENDPATH**/ ?>