<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <ul class="cs-user-accounts-list">
        <li class="<?php echo e(route::is('dashboard.listVehicles') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.listVehicles')); ?>">Mis Motos</a></li>
        <li class="<?php echo e(route::is('dashboard.listAccesories') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard.listAccesories')); ?>">Mis Accesorios</a></li>
        <li class="<?php echo e(route::is('favorite.index') ? 'active' : ''); ?>"><a href="<?php echo e(route('favorite.index')); ?>">Mis Favoritos</a></li>
        <li class="<?php echo e(route::is('profile.viewProfile') ? 'active' : ''); ?>"><a href="<?php echo e(route('profile.viewProfile')); ?>">Peril</a></li>
        <li><a href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                        class="icon fa fa-sign-out">Salir</a></li>
    </ul>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</div><?php /**PATH D:\Webs\dedosruedas\resources\views/web/user/_menu.blade.php ENDPATH**/ ?>