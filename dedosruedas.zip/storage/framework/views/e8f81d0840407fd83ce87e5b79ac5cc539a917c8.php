<?php $__env->startSection('body', 'wp-automobile single-post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-section">
        <div class="page-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="cs-section-title" style="margin-bottom:20px;">
                            <h3 style="text-align:left;">Ingresar</h3>
                        </div>
                    </div>

                    <div class="col-sm-6 col-xs-6">
                        <div class="cs-signin">
                            <div class="row">
                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="cs-field-holder">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <label>Email *</label>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <input id="email" type="email"
                                                   class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                                   name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                                   autofocus>

                                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>
                                    <div class="cs-field-holder">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <label>Contraseña *</label>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <input id="password" type="password"
                                                   class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                                   name="password" required autocomplete="current-password">

                                            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                        </div>
                                    </div>

                                    <div class="cs-field-holder">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="cs-btn-submit">
                                                <input type="submit" value="Ingresar">
                                            </div>
                                            <a href="<?php echo e(route('password.request')); ?>" class="cs-forgot-password"><i
                                                        class="cs-color icon-help-with-circle"
                                                        data-toggle="tooltip" data-placement="top"
                                                        title="Se envia un email para recuperar clave"></i>Recuperar
                                                Contraseña</a>
                                        </div>
                                    </div>

                                    <div class="cs-field-holder">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="remember"
                                                       id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                                <label class="form-check-label" for="remember">
                                                    <?php echo e(__('Recordarme')); ?>

                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xs-6">
                        <div class="cs-column-text" style="padding: 30px">
                            <p>Si no tenes cuenta en la plataforma, te invitamos a
                                registrarte y vender tu moto o los accesorios de tu motocicleta totalmente gratis, sin
                                intermediarios ni comisiones.</p>
                            <a href="<?php echo e(route('register')); ?>" class="cs-button"
                               style="color:#fff;font-size:11px; padding:12px 45px; font-weight:bold; text-transform:uppercase;">Registrarse</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\dedosruedas\resources\views/auth/login.blade.php ENDPATH**/ ?>