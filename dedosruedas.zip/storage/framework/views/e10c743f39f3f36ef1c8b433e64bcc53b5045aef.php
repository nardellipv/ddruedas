<script>
    function checkOnlyOne(b) {

        var x = document.getElementsByClassName('typeCheck');
        var i;

        for (i = 0; i < x.length; i++) {
            if (x[i].value != b) x[i].checked = false;
        }
    }
</script>

<aside class="section-sidebar col-lg-3 col-md-3 col-sm-12 col-xs-12">
    <div class="cs-listing-filters">
        <div class="cs-search">
            <form action="<?php echo e(route('item.search')); ?>" method="GET" class="search-form">
                <div class="cs-search">
                    <div class="select-input">
                        <select tabindex="1" class="chosen-select" name="province">
                            <?php if(isset($provinceName->name)): ?>
                                <option value="<?php echo e($provinceName->id); ?>"><?php echo e($provinceName->name); ?></option>
                            <?php else: ?>
                                <option>Provincia</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($province->id); ?>"><?php echo e($province->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="cs-select-model">

                    <ul class="cs-checkbox-list mCustomScrollbar" data-mcs-theme="dark">
                        <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="input-radio">
                                    <?php if(isset($typeName)): ?>
                                        <input id="type<?php echo e($type->id); ?>" type="checkbox" name="type"
                                               class="typeCheck checked"
                                               value="<?php echo e($type->id); ?>" onclick="checkOnlyOne(this.value);"
                                                <?php echo e($typeName->id == $type->id ? 'checked' : ''); ?>>
                                        <label for="type<?php echo e($type->id); ?>"><?php echo e($type->name); ?></label>
                                    <?php else: ?>
                                        <input id="type<?php echo e($type->id); ?>" type="checkbox" name="type"
                                               class="typeCheck checked"
                                               value="<?php echo e($type->id); ?>" onclick="checkOnlyOne(this.value);">
                                        <label for="type<?php echo e($type->id); ?>"><?php echo e($type->name); ?></label>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
                <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingsix">
                            <a class="collapsed" role="button" data-toggle="collapse" href="#collapsesix"
                               aria-expanded="false" aria-controls="collapsesix">
                                Año
                            </a>
                        </div>
                        <div id="collapsesix" class="panel-collapse collapse in" role="tabpanel"
                             aria-labelledby="headingsix">
                            <div class="panel-body">
                                <div class="cs-engine-capacity">
                                    <form>
                                        <input id="engine" type="text" name="year" class="span2"
                                               data-slider-min="<?php echo e($minYear); ?>"
                                               data-slider-max="2020" data-slider-step="1"
                                               data-slider-value="[<?php echo e($minYear); ?>,2020]"/>
                                        <div class="selector-value">
                                            <span><?php echo e($minYear); ?></span>
                                            <span class="pull-right">2020</span>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingThree">
                            <a class="collapsed" role="button" data-toggle="collapse" href="#collapseThree"
                               aria-expanded="false" aria-controls="collapseThree">
                                Precio
                            </a>
                        </div>

                        <div id="collapseThree" class="panel-collapse collapse in" role="tabpanel"
                             aria-labelledby="headingThree">
                            <div class="panel-body">
                                <div class="cs-price-range">
                                    <input id="price" type="text" name="price" class="span2"
                                           data-slider-min="0"
                                           data-slider-max="<?php echo e($maxPrice); ?>" data-slider-step="15000"
                                           data-slider-value="[0,<?php echo e($maxPrice); ?>]"/>
                                    <div class="selector-value">
                                        <span>$0</span>
                                        <span class="pull-right">$<?php echo e($maxPrice); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="cs-field">
                        <div class="cs-btn-submit">
                            <input type="submit" value="Buscar" placeholder="">
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="widget woocommerce widget_shopping_cart">
            <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <!-- DedosItemsListado -->
            <ins class="adsbygoogle"
                 style="display:block"
                 data-ad-client="ca-pub-7543412924958320"
                 data-ad-slot="8646794594"
                 data-ad-format="auto"
                 data-full-width-responsive="true"></ins>
            <script>
                (adsbygoogle = window.adsbygoogle || []).push({});
            </script>
        </div>
    </div>
</aside><?php /**PATH D:\Webs\dedosruedas\resources\views/web/items/_asideList.blade.php ENDPATH**/ ?>