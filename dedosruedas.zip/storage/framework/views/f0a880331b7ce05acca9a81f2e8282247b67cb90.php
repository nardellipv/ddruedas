<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DeDosRuedas | <?php echo $__env->yieldContent('title', 'Cambiar tu moto de forma fácil'); ?> <?php echo e(date('Y')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta-description','Portal dedicado 100% a la venta de motocicletas en toda Argentina.'); ?>">

    <link href="<?php echo e(asset('styleWeb/assets/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/bootstrap-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/iconmoon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/chosen.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/cs-automobile-plugin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/color.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/widget.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('styleWeb/assets/css/responsive.css')); ?>" rel="stylesheet">

    <link rel="apple-touch-icon" sizes="57x57" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-57x57.png')); ?>">
    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-60x60.png')); ?>">
    <link rel="apple-touch-icon" sizes="72x72" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-72x72.png')); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-76x76.png')); ?>">
    <link rel="apple-touch-icon" sizes="114x114" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-114x114.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="144x144" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-144x144.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('styleWeb/assets/fav/apple-icon-180x180.png')); ?>">
    <link rel="icon" type="image/png" sizes="192x192"
          href="<?php echo e(asset('styleWeb/assets/fav/android-icon-192x192.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('styleWeb/assets/fav/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('styleWeb/assets/fav/favicon-96x96.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('styleWeb/assets/fav/favicon-16x16.png')); ?>">

    

    <?php echo $__env->yieldContent('css'); ?>
    <?php echo notifyCss(); ?>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js') }}"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js') }}"></script>
    <![endif]-->
    <script src="<?php echo e(asset('styleWeb/assets/scripts/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('styleWeb/assets/scripts/modernizr.js')); ?>"></script>
    <script src="<?php echo e(asset('styleWeb/assets/scripts/bootstrap.min.js')); ?>"></script>

    <?php echo htmlScriptTagJsApi(); ?>

    <?php echo $__env->make('external.analytics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('external.adsenses', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="<?php echo $__env->yieldContent('body'); ?>">
<div class="wrapper">
    <!-- Header Start -->
<?php echo $__env->make('web.parts._menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header End -->

<?php echo $__env->make('notify::messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Main Start -->
    <div class="main-section">
    <?php if(Route::is('home')): ?>
        <!--Main Banner-->
        <?php echo $__env->make('web.parts._mainBanner', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Main Banner-->
            <!--Main Banner form-->
        
    <?php endif; ?>
    <!--Main Banner form-->
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Main End -->
    <!-- Footer Start -->
<?php echo $__env->make('web.parts._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Footer End -->
</div>
<script src="<?php echo e(asset('styleWeb/assets/scripts/responsive.menu.js')); ?>"></script>
<script src="<?php echo e(asset('styleWeb/assets/scripts/chosen.select.js')); ?>"></script>
<script src="<?php echo e(asset('styleWeb/assets/scripts/slick.js')); ?>"></script>
<script src="<?php echo e(asset('styleWeb/assets/scripts/echo.js')); ?>"></script>

<?php echo notifyJs(); ?>
<?php echo $__env->yieldContent('js'); ?>
<!-- Put all Functions in functions.js -->
<script src="<?php echo e(asset('styleWeb/assets/scripts/functions.js')); ?>"></script>
</body>

</html><?php /**PATH D:\Webs\dedosruedas\resources\views/layouts/main.blade.php ENDPATH**/ ?>