<aside class="page-sidebar col-lg-3 col-md-3 col-sm-12 col-xs-12">
    <div class="widget woocommerce widget_product_categories">
        <h6>Categorías</h6>
        <ul>
            <li class="cat-item cat-item-3 cat-parent">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('accessory.category', $category->slug)); ?>"><?php echo e($category->name); ?>

                        <span>(<?php echo e($category->accessory_count); ?>)</span></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="widget woocommerce widget_top_rated_products">
        <h6>Últimos publicados</h6>
        <ul class="product_list_widget">
            <?php $__currentLoopData = $accessoriesLast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessoryLast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('accessory.detail', $accessoryLast)); ?>">
                        <img src="<?php echo e(asset('users/'.$accessoryLast->user_id.'/images/accessory/700x700-'.$accessoryLast->picture)); ?>"
                             alt="shop"/>
                        <span class="product-title"><?php echo e($accessoryLast->name); ?></span>
                    </a>
                    <span class="amount cs-color">$ <?php echo e($accessoryLast->price); ?></span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="widget woocommerce widget_shopping_cart">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- DeDosAccessoryList -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-7543412924958320"
             data-ad-slot="7661015980"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
            (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>
</aside><?php /**PATH D:\Webs\dedosruedas\resources\views/web/accessories/_asideAccessories.blade.php ENDPATH**/ ?>